"""Mock backends for CUDA-free, laptop-only verification.

These let the whole ``ConversationEngine`` run end-to-end on a Mac with no
GPU — the Phase 1a acceptance goal. They implement the voxedge ABCs with
trivial deterministic behaviour.
"""
from __future__ import annotations

import time
from typing import Any, AsyncIterator, Iterator, Optional

import numpy as np


class PoolSaturatedError(RuntimeError):
    """Duck-type of the production ``PoolSaturatedError`` (app/main.py:592-610).

    Carries ``status == 4429`` + ``max_slots`` so the engine's
    :func:`voxedge.engine.conversation._is_pool_saturated` recognizes it
    WITHOUT importing the app package. Used by the mock backends to exercise
    the M4 typed-error path in tests.
    """

    status = 4429

    def __init__(self, message: str = "pool saturated", max_slots: int = 1):
        super().__init__(message)
        self.max_slots = max_slots

from voxedge.backends.base import (
    ASRBackend,
    ASRCapability,
    ASRStream,
    LLMBackend,
    LLMEvent,
    TranscriptionResult,
    TTSBackend,
    TTSCapability,
    VADBackend,
    VADSession,
)


# ═══════════════════════════════════════════════════════════════════════
# Mock ASR
# ═══════════════════════════════════════════════════════════════════════


class MockASRStream(ASRStream):
    """Accumulates fed audio; emits a deterministic transcript on finalize.

    Partials grow with each chunk so the engine's partial-polling path is
    exercised. ``transcript`` lets a test pin the final text.
    """

    def __init__(
        self,
        transcript: str = "hello world",
        language: Optional[str] = "English",
        *,
        finalize_block_s: float = 0.0,
    ):
        self._transcript = transcript
        self._language = language
        self._chunks = 0
        self._cancelled = False
        # Test hook (M1): block inside finalize() to simulate a wedged ASR
        # worker that never produces a final → drives the per-turn deadline.
        self._finalize_block_s = finalize_block_s

    def accept_waveform(self, sample_rate: int, samples: "np.ndarray") -> None:
        if self._cancelled:
            return
        self._chunks += 1

    def get_partial(self) -> tuple[str, bool]:
        if self._cancelled or self._chunks == 0:
            return "", False
        # Reveal one word of the transcript per chunk fed, as a partial.
        words = self._transcript.split()
        n = min(self._chunks, len(words))
        return " ".join(words[:n]), False

    def finalize(self) -> tuple[str, Optional[str]]:
        if self._finalize_block_s > 0:
            # Runs in the manager's executor thread, not the event loop.
            time.sleep(self._finalize_block_s)
        if self._cancelled:
            return "", None
        return self._transcript, self._language

    def cancel_and_finalize(self) -> None:
        self._cancelled = True


class MockASR(ASRBackend):
    """Streaming + offline mock ASR. No env, no GPU."""

    def __init__(
        self,
        transcript: str = "hello world",
        language: Optional[str] = "English",
        sample_rate: int = 16000,
        *,
        finalize_block_s: float = 0.0,
        saturate_on_create: bool = False,
        max_slots: int = 1,
        concurrency: Optional[Any] = None,
    ):
        self._transcript = transcript
        self._language = language
        self._sr = sample_rate
        self._ready = False
        # Test hooks.
        self._finalize_block_s = finalize_block_s
        self._saturate_on_create = saturate_on_create
        self._max_slots = max_slots
        # Concurrency-capability override (slot layer, spec §3.1). Accepts a
        # ``ConcurrencyCapability``, a plain dict, or None (→ ABC default).
        self._concurrency = concurrency

    @property
    def name(self) -> str:
        return "mock_asr"

    @property
    def capabilities(self) -> set[ASRCapability]:
        return {ASRCapability.OFFLINE, ASRCapability.STREAMING, ASRCapability.LANGUAGE_ID}

    @property
    def sample_rate(self) -> int:
        return self._sr

    def is_ready(self) -> bool:
        return self._ready

    def preload(self) -> None:
        self._ready = True

    def transcribe(self, audio_bytes: bytes, language: str = "auto") -> TranscriptionResult:
        return TranscriptionResult(text=self._transcript, language=self._language)

    def create_stream(self, language: str = "auto") -> ASRStream:
        # M4 test hook: backend slot-pool saturated → reject at stream open.
        if self._saturate_on_create:
            raise PoolSaturatedError("asr pool saturated", max_slots=self._max_slots)
        return MockASRStream(
            transcript=self._transcript,
            language=self._language,
            finalize_block_s=self._finalize_block_s,
        )

    def concurrency_capability(self) -> Any:
        if self._concurrency is not None:
            return self._concurrency
        return super().concurrency_capability()


# ═══════════════════════════════════════════════════════════════════════
# Mock TTS
# ═══════════════════════════════════════════════════════════════════════


class MockTTS(TTSBackend):
    """Emits deterministic PCM: one chunk per sentence, length proportional
    to text length so callers can assert audio was produced."""

    def __init__(
        self,
        sample_rate: int = 16000,
        chunk_bytes_per_char: int = 4,
        *,
        first_chunk_block_s: float = 0.0,
        saturate: bool = False,
        max_slots: int = 1,
        concurrency: Optional[Any] = None,
    ):
        self._sr = sample_rate
        self._cbpc = chunk_bytes_per_char
        self._ready = False
        # Test hooks (M3/M4): block before the first chunk to wedge the synth
        # thread (drives the chunk watchdog), or raise PoolSaturatedError.
        self._first_chunk_block_s = first_chunk_block_s
        self._saturate = saturate
        self._max_slots = max_slots
        # Concurrency-capability override (slot layer, spec §3.1).
        self._concurrency = concurrency

    @property
    def name(self) -> str:
        return "mock_tts"

    @property
    def capabilities(self) -> set[TTSCapability]:
        return {TTSCapability.BASIC_TTS, TTSCapability.STREAMING}

    @property
    def sample_rate(self) -> int:
        return self._sr

    def is_ready(self) -> bool:
        return self._ready

    def preload(self) -> None:
        self._ready = True

    def synthesize(
        self,
        text: str,
        speaker_id: Optional[int] = None,
        speed: Optional[float] = None,
        pitch_shift: Optional[float] = None,
        language: Optional[str] = None,
        **kwargs,
    ) -> tuple[bytes, dict]:
        pcm = self._pcm_for(text)
        return pcm, {"sample_rate": self._sr, "text": text}

    def generate_streaming(
        self,
        text: str,
        *,
        language: Optional[str] = None,
        speaker: Optional[str] = None,
        cancel_token: Optional[Any] = None,
        **kwargs,
    ) -> Iterator[bytes]:
        # M4 test hook: backend slot-pool saturated → raise before any chunk.
        if self._saturate:
            raise PoolSaturatedError("tts pool saturated", max_slots=self._max_slots)
        # M3 test hook: wedge the synth thread before the first chunk so the
        # per-chunk watchdog fires (cooperative on cancel_token).
        if self._first_chunk_block_s > 0:
            deadline = time.monotonic() + self._first_chunk_block_s
            while time.monotonic() < deadline:
                if cancel_token is not None and cancel_token.is_set():
                    return
                time.sleep(0.02)
        # Emit the PCM in a few sub-chunks so barge-in (cancel_token) can be
        # exercised mid-stream.
        pcm = self._pcm_for(text)
        step = max(2, len(pcm) // 3) & ~1  # even byte boundary (int16)
        for i in range(0, len(pcm), step or len(pcm)):
            if cancel_token is not None and cancel_token.is_set():
                return
            yield pcm[i : i + step]

    def concurrency_capability(self) -> Any:
        if self._concurrency is not None:
            return self._concurrency
        return super().concurrency_capability()

    def _pcm_for(self, text: str) -> bytes:
        n_samples = max(1, len(text) * self._cbpc // 2)
        return (np.zeros(n_samples, dtype=np.int16)).tobytes()


# ═══════════════════════════════════════════════════════════════════════
# Mock VAD
# ═══════════════════════════════════════════════════════════════════════


class MockVADSession(VADSession):
    """Deterministic VAD: emits SPEECH_START on the first non-silent chunk,
    SPEECH_END once ``silence_chunks`` consecutive silent chunks are seen.

    "Silent" = all samples below ``threshold`` magnitude. This lets a test
    drive segmentation purely from the audio it feeds.
    """

    def __init__(self, silence_chunks: int = 2, threshold: float = 0.01):
        self._silence_needed = max(1, silence_chunks)
        self._threshold = threshold
        self._in_speech = False
        self._silence = 0

    def process(self, samples: "np.ndarray") -> Optional[str]:
        if samples.dtype == np.int16:
            samples = samples.astype(np.float32) / 32768.0
        loud = bool(np.any(np.abs(samples) >= self._threshold))
        if loud:
            self._silence = 0
            if not self._in_speech:
                self._in_speech = True
                return self.SPEECH_START
            return None
        # silent chunk
        if self._in_speech:
            self._silence += 1
            if self._silence >= self._silence_needed:
                self._in_speech = False
                self._silence = 0
                return self.SPEECH_END
        return None

    def reset(self) -> None:
        self._in_speech = False
        self._silence = 0


class MockVAD(VADBackend):
    def __init__(self, silence_chunks: int = 2, threshold: float = 0.01):
        self._silence_chunks = silence_chunks
        self._threshold = threshold

    @property
    def name(self) -> str:
        return "mock_vad"

    def create_session(
        self, sample_rate: int = 16000, silence_ms: int = 400, **kwargs
    ) -> VADSession:
        return MockVADSession(
            silence_chunks=self._silence_chunks, threshold=self._threshold
        )


# ═══════════════════════════════════════════════════════════════════════
# Mock LLM
# ═══════════════════════════════════════════════════════════════════════


class MockLLM(LLMBackend):
    """Echoes a canned reply word-by-word as text deltas."""

    def __init__(self, reply: str = "Sure, here is your answer."):
        self._reply = reply

    async def stream(
        self, messages: list[dict[str, Any]], **kw: Any
    ) -> AsyncIterator[str]:
        for word in self._reply.split():
            yield word + " "


__all__ = [
    "MockASR",
    "MockASRStream",
    "MockTTS",
    "MockVAD",
    "MockVADSession",
    "MockLLM",
    "PoolSaturatedError",
]
